namespace Aula09DB.Models;

class Pedido
{
    public int CodPedido { get; set; }
    public DateTime PrazoEntrega { get; set; }
    public DateTime DataPedido { get; set; }
    public int PedidoCodCliente { get; set; }
    public int PedidoCodVendedor { get; set; }

    public Pedido(int codPedido, DateTime prazoEntrega, DateTime dataPedido, int pedidoCodCleinte, int pedidoCodVendedor) {
        CodPedido = codPedido;
        PrazoEntrega = prazoEntrega;
        DataPedido = dataPedido;
        PedidoCodCliente = pedidoCodCleinte;
        PedidoCodVendedor = pedidoCodVendedor;
    }
}