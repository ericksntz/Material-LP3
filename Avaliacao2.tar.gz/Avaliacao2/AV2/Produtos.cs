namespace Aula09DB.Models;

class Produtos
{
    public int CodProduto { get; set; }
    public string Descricao { get; set; }
    public string ValorUnitario { get; set; }

    public Produtos(int codProduto, string descricao, string valorUnitario)
    {
        CodProduto = codProduto;
        Descricao = descricao;
        ValorUnitario = valorUnitario;
    }
}