namespace Aula09DB.Models;

class ItensPedido
{
    public int CodItemPedido { get; set; }
    public int ItemPedidoCodProduto { get; set; }
    public int ItemPedidoCodPedido { get; set; }
    public int Quantidade { get; set; }

    public ItensPedido(int codItemPedido, int itemPedidoCodProduto, int itemPedidoCodPedido, int quantidade) 
    {
        CodItemPedido = codItemPedido;
        ItemPedidoCodProduto = itemPedidoCodProduto;
        ItemPedidoCodPedido = itemPedidoCodPedido;
        Quantidade = quantidade;
    }
}